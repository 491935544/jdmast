﻿// JSON格式互转;
var iJSON = iJSON || {
	strJSON: (function(c) {
		if(c == undefined) {
			return '""'
		}
		var d = [];
		if(typeof c == "string") {
			return '"' + c.replace(/([\"\\])/g, "\\$1").replace(/(\n)/g, "\\n").replace(/(\r)/g, "\\r").replace(/(\t)/g, "\\t") + '"'
		}
		if(typeof c == "object") {
			if(!c.sort) {
				for(var b in c) {
					d.push('"' + b + '":' + iJSON.strJSON(c[b]))
				}
				if(!!document.all && !/^\n?function\s*toString\(\)\s*\{\n?\s*\[native code\]\n?\s*\}\n?\s*$/.test(c.toString)) {
					d.push("toString:" + c.toString().toString())
				}
				d = "{" + d.join() + "}"
			} else {
				for(var b = 0, a = c.length; b < a; b++) {
					d.push(iJSON.strJSON(c[b]))
				}
				d = "[" + d.join() + "]"
			}
			return d
		}
		return c.toString().replace(/\"\:/g, '":""')
	}),
	JSONstr: (function(str) {
		try {
			return eval("(" + str + ")")
		} catch(e) {
			return false
		}
	})
};;
(function() {

	if(window.JDSMART) {
		return
	}

	var JSBridge;
	var readyCallback;

	function init(config) {
		JSBridge = config.bridge;
		JSBridge.init(function(msg, callback) {

		});
		readyCallback();
	}

	function ready(fn) {
		window.setTimeout(fn, 100);
	}

	var fn = {
		getSnapshot: function(successCallback, failedCallback) {
			// pc;
			var data = {
				"type": "getSnapshot",
				"url": "/f/service/getStreamSnapshot",
				"data": ""
			}
			new window.SmartPcSendAjax("", data, function(result) {
				if(result.status != 0) {
					if(failedCallback) {
						failedCallback(result.error);
					}
				} else {
					successCallback(result.result);
				}
			});
		},
		getUserId: function(successCallback, failedCallback) {
			// pc;
			var data = {
				"type": "getUserId",
				"url": "/c/service/getUserNewUId",
				"data": ""
			}
			new window.SmartPcSendAjax("", data, function(result) {
				if(result.status != 0) {
					if(failedCallback) {
						failedCallback(result.error);
					}
				} else {
					successCallback(result.result);
				}
			});
		},
		getWifiHistory: function(params, successCallback, failedCallback) {
			// pc;
			var data = {
				"type": "getWifiHistory",
				"url": "/f/service/getHistoryData",
				"data": iJSON.strJSON(params)
			}
			new window.SmartPcSendAjax("", data, function(result) {
				if(result.status != 0) {
					if(failedCallback) {
						failedCallback(result.error);
					}
				} else {
					successCallback(result.result);
				}
			});
		},
		initDeviceData: function(successCallback) {
			// pc;
			var data = {
				"type": "initDeviceData",
				"url": "/f/service/initDeviceData",
				"data": ""
			}
			new window.SmartPcSendAjax("", data, function(result) {
				// 将此接口的结果，result JSON字符串，转换为对象;
				if(result.result) {
					result = iJSON.JSONstr(result.result);
				}
				successCallback(result);
			});
		},
		controlDevice: function(params, successCallback, failedCallback) {
			// pc;
			var data = {
				"type": "controlDevice",
				"url": "/f/service/controlDevice",
				"data": iJSON.strJSON(params["command"])
			}
			new window.SmartPcSendAjax("", data, function(result) {
				if(result.status != 0) {
					if(failedCallback) {
						failedCallback(result.error);
					}
				} else {
					successCallback(result.result);
				}
			});
		},
		getHistory: function(successCallback) {
			// pc;
			var data = {
				"type": "getSnapshot",
				"url": "/c/service/getProductHistoryRecordList",
				"data": ""
			}
			new window.SmartPcSendAjax("", data, function(result) {
				successCallback(result);
			});
		},
		getRecipeList: function(params, successCallback, failedCallback) {
			// pc;
		},
		getRecipeDetail: function(params, successCallback, failedCallback) {
			// pc;
		},
		excuteRecipe: function(params, successCallback, failedCallback) {
			// pc;
		},
		getCurrentRecipe: function(params, successCallback, failedCallback) {
			// pc;
		}
	};

	var app = {
		getNetworkType: function(successCallback) {
			// pc;
			var result = {
				TypeName: "wifi"
			}
			successCallback(result);
		},
		openUrl: function(url) {
			// pc;
			window.open(url);
		},
		config: function(data) {
			// pc;
		},
		alert: function(data, successCallback) {
			// pc;
			if(window.confirm(data.messageTitle)) {
				successCallback(1);
			} else {
				successCallback(0);
			}
		},
		toast: function(data, successCallback) {
			// pc;
		}
	};

	var util = {
		get: function(url, callBack) {
			JSBridge.send({
				type: 'get',
				url: url
			}, function(result) {
				callBack(result);
			});
		},

		post: function(url, params, callBack) {
			// pc;
			var data = {
				"type": "post",
				"url": url,
				"data": iJSON.strJSON(params)
			}
			new window.SmartPcSendAjax("", data, function(result) {
				callBack(result);
			});
		},

		getToken: function(appkey, callBack) {
			JSBridge.send({
				type: 'token',
				data: appkey
			}, function(result) {
				callBack(result);
			});
		}
	};

	window.JDSMART = {
		init: init,
		ready: ready,
		io: fn,
		app: app,
		util: util
	};
	try {
		document.addEventListener('JDSmartBridgeReady', function onReady(ev) {
			JDSMART.init({
				'bridge': ev.bridge
			});
		});
	} catch(e) {}

})();
// 通用AJAX方法;
window.SmartPcSendAjax = function(url, data, callBack) {
		var url = url || "/requestServer";
		url = url + "?v=" + new Date().getTime();
		var XHR = null;
		if(window.XMLHttpRequest) {
			XHR = new XMLHttpRequest();
		} else if(window.ActiveXObject) {
			XHR = new ActiveXObject("Microsoft.XMLHTTP");
		}

		XHR.open("POST", url);
		XHR.setRequestHeader("Accept", "application/json; charset=UTF-8;");
		XHR.setRequestHeader("Content-Type", "application/json; charset=UTF-8;");
		XHR.send(iJSON.strJSON(data));
		XHR.onreadystatechange = function() {
			if((XHR.readyState == 4) && (XHR.status == 200)) {
				var jsonData = iJSON.JSONstr(XHR.responseText);
				callBack(jsonData);
			}
		}
	}
	// 验证当前本地环境版本;
window.localWarVersion = 1;;
(function() {
	new window.SmartPcSendAjax("/getLocalVersion", "", function(data) {
		if(data < window.localWarVersion) {
			alert("当前H5本地调试环境版本过低，请升级后进行调试");
		}
	});
})();

// 推送;
var wsJS = {};
wsJS.ws = null;
wsJS.startServer = function() {
	window.setTimeout(wsJS.startServer, 5000);
	if(wsJS.ws) {
		return;
	}
	var url = "ws://localhost:9091/websocket";
	if("WebSocket" in window) {
		wsJS.ws = new WebSocket(url);

	} else if("MozWebSocket" in window) {
		wsJS.ws = new MozWebSocket(url);
	} else {
		return;
	}
	wsJS.ws.onopen = function() {
		try {
			console.log("websocket open!");
		} catch(e) {}

	};
	wsJS.ws.onmessage = function(event) {
		try {
			console.log(event.data);
		} catch(e) {}

		if(window.onReceive) {
			window.onReceive(event.data);
		}
	};
	wsJS.ws.onclose = function() {
		wsJS.ws = null;
		try {
			console.log("websocket closed!");
		} catch(e) {}
	};
	wsJS.ws.onerror = function() {
		wsJS.ws = null;
		try {
			console.log("websocket error");
		} catch(e) {}
	};
}
wsJS.startServer();
﻿/* 
 * 日期插件
 * 滑动选取日期（年，月，日）
 * V1.1
 */
(function($) {
	$.fn.date = function(options, Ycallback, Ncallback) {

		var timeZoneCn = new Array(
			"UTC-12:00   埃尼威托克岛",
			"UTC-12:00  夸贾林岛",
			"UTC-11:00  中途岛",
			"UTC-11:00  东萨摩亚",
			"UTC-10:00  夏威夷",
			"UTC-9:00  阿拉斯加",
			"UTC-8:00  太平洋时间(美国和加拿大)",
			"UTC-8:00  蒂华纳",
			"UTC-7:00  山地时间(美国和加拿大)",
			"UTC-7:00  亚利桑那",
			"UTC-6:00  中部时间(美国和加拿大)",
			"UTC-6:00  墨西哥城",
			"UTC-6:00  特古西加尔巴",
			"UTC-6:00  萨斯喀彻温省",
			"UTC-5:00  东部时间(美国和加拿大)",
			"UTC-5:00  印第安那州(东部)",
			"UTC-5:00  波哥大",
			"UTC-5:00  利马",
			"UTC-5:00  基多",
			"UTC-4:00  大西洋时间(加拿大)",
			"UTC-4:00  加拉加斯",
			"UTC-4:00  拉巴斯",
			"UTC-3:00  巴西利亚",
			"UTC-3:00  布宜诺斯艾利斯",
			"UTC-3:00  乔治敦",
			"UTC-2:00  中大西洋",
			"UTC-1:00  亚速尔群岛",
			"UTC-1:00  佛得角群岛",
			"格林尼治平均时:伦敦",
			"格林尼治平均时:都柏林",
			"格林尼治平均时:爱丁堡",
			"格林尼治平均时:里斯本",
			"格林尼治平均时:卡萨布兰卡",
			"格林尼治平均时:蒙罗维亚",

			"UTC+1:00  阿姆斯特丹",
			"UTC+1:00  柏林",
			"UTC+1:00  伯尔尼",
			"UTC+1:00  罗马",
			"UTC+1:00  维也纳",
			"UTC+1:00  贝尔格莱德",
			"UTC+1:00  布拉迪斯拉发",
			"UTC+1:00  布达佩斯",
			"UTC+1:00  卢布尔雅那",
			"UTC+1:00  布拉格",
			"UTC+1:00  哥本哈根",
			"UTC+1:00  布鲁赛尔",
			"UTC+1:00  马德里",
			"UTC+1:00  巴黎",
			"UTC+1:00  萨拉热窝",
			"UTC+1:00  斯科普里",
			"UTC+1:00  索非亚",
			"UTC+1:00  华沙",
			"UTC+1:00  萨格勒布",

			"UTC+2:00  布加勒斯特",
			"UTC+2:00  哈拉雷",
			"UTC+2:00  比勒陀尼亚",
			"UTC+2:00  赫尔辛基",
			"UTC+2:00  里加",
			"UTC+2:00  塔林",
			"UTC+2:00  开罗",
			"UTC+2:00  雅典",
			"UTC+2:00  明斯克",
			"UTC+2:00  以色列",

			"UTC+3:00  巴格达",
			"UTC+3:00  科威特",
			"UTC+3:00  利雅得",
			"UTC+3:00  莫斯科",
			"UTC+3:00  圣彼得堡",
			"UTC+3:00  伏尔加格勒",
			"UTC+3:00  内罗毕",

			"UTC+4:00  阿布扎比",
			"UTC+4:00  马斯喀特",
			"UTC+4:00  巴库",
			"UTC+4:00  第比利斯",

			"UTC+5:00  叶卡特琳堡",
			"UTC+5:00  伊斯兰堡",
			"UTC+5:00  卡拉奇",
			"UTC+5:00  塔什干",

			"UTC+6:00  阿拉木图",
			"UTC+6:00  达卡",
			"UTC+6:00  科伦坡",

			"UTC+7:00  曼谷",
			"UTC+7:00  河内",
			"UTC+7:00  雅加达",

			"UTC+8:00  北京",
			"UTC+8:00  重庆",
			"UTC+8:00  广州",
			"UTC+8:00  上海",
			"UTC+8:00  香港",
			"UTC+8:00  乌鲁木齐",
			"UTC+8:00  台北",
			"UTC+8:00  新加坡",
			"UTC+8:00  佩思",

			"UTC+9:00  平壤",
			"UTC+9:00  汉城",
			"UTC+9:00  东京",
			"UTC+9:00  大阪",
			"UTC+9:00  札幌",
			"UTC+9:00  雅库茨克",

			"UTC+10:00  布里斯班",
			"UTC+10:00  关岛",
			"UTC+10:00  莫尔兹比港",
			"UTC+10:00  霍巴特",
			"UTC+10:00  堪培拉",
			"UTC+10:00  墨尔本",
			"UTC+10:00  悉尼",

			"UTC+11:00  马加丹",
			"UTC+11:00  所罗门群岛",
			"UTC+11:00  新喀里多尼亚",

			"UTC+12:00  奥克兰",
			"UTC+12:00  惠灵顿",
			"UTC+12:00  斐济",
			"UTC+12:00  堪察加半岛",
			"UTC+12:00  马绍尔群岛",

			"UTC-3:30  纽芬兰",
			"UTC+3:30  德黑兰",
			"UTC+4:30  喀布尔",
			"UTC+5:30  孟买",
			"UTC+5:30  加尔各答",
			"UTC+5:30  马德拉斯",
			"UTC+5:30  新德里",
			"UTC+9:30  阿得莱德，达尔文"

		);

		var timeZoneEn = new Array(
			"UTC-12:00 Eniwetok",
			"UTC-12:00 Kwajalein Island",
			"UTC-11:00 Midway Islands",
			"UTC-11:00 Eastern Samoa",
			"UTC-10:00 Hawaii",
			"UTC-9:00 Alaska",
			"UTC-8:00 Pacific time (USA and Canada)",
			"UTC-8:00 Tijuana",
			"UTC-7:00 Mountain time (USA and Canada)",
			"UTC-7:00 Arizona",
			"UTC-6:00 Central time (USA and Canada)",
			"UTC-6:00 Mexico City",
			"UTC-6:00 Tegucigalpa",
			"UTC-6:00 Saskatchewan",
			"UTC-6:00 Eastern time (USA and Canada)",
			"UTC-5:00 Indiana (Eastern)",
			"UTC-5:00 Bogota",
			"UTC-5:00 Lima",
			"UTC-5:00 Quito",
			"UTC-4:00 The Atlantic time (Canada)",
			"UTC-4:00 Caracas",
			"UTC-4:00 La Paz",
			"UTC-3:00 Brasilia",
			"UTC-3:00 Buenos Aires",
			"UTC-3:00 Georgetown",
			"UTC-2:00 Mid-Atlantic",
			"UTC-1:00 Azores",
			"UTC-1:00 The Cape Verde Islands",
			"Greenwich: London",
			"Greenwich: Dublin",
			"Greenwich: Edinburgh",
			"Greenwich: Lisbon",
			"Greenwich:Casablanca",
			"Greenwich:Monrovia",

			"UTC+1:00 Amsterdam",
			"UTC+1:00 Berlin",
			"UTC+1:00 Berne",
			"UTC+1:00 Rome",
			"UTC+1:00 Vienna",
			"UTC+1:00 Belgrade",
			"UTC+1:00 Bratislava",
			"UTC+1:00 Budapest",
			"UTC+1:00 Ljubljana",
			"UTC+1:00 Bragg",
			"UTC+1:00 Copenhagen",
			"UTC+1:00 Brussels",
			"UTC+1:00 Madrid",
			"UTC+1:00 Paris",
			"UTC+1:00 Sarajevo",
			"UTC+1:00 Skopje",
			"UTC+1:00 Sophia",
			"UTC+1:00 Warsaw",
			"UTC+1:00 Zagreb",

			"UTC+2:00 Bucharest",
			"UTC+2:00 Harare",
			"UTC+2:00 Pretoria",
			"UTC+2:00 Helsinki",
			"UTC+2:00 Riga",
			"UTC+2:00 Tallinn",
			"UTC+2:00 Cairo",
			"UTC+2:00 Athens",
			"UTC+2:00 Minsk",
			"UTC+2:00 Israel",

			"UTC+3:00 Baghdad",
			"UTC+3:00 Kuwait",
			"UTC+3:00 Riyadh",
			"UTC+3:00 Moscow",
			"UTC+3:00 St.Petersburg",
			"UTC+3:00 Volgograd",
			"UTC+3:00 Nairobi",

			"UTC+4:00 Abu Dhabi",
			"UTC+4:00 Muscat",
			"UTC+4:00 Baku",
			"UTC+4:00 Tbilisi",

			"UTC+5:00 Ekaterinburg",
			"UTC+5:00 Islamabad",
			"UTC+5:00 Karachi",
			"UTC+5:00 Tashkent",

			"UTC+6:00 Almaty",
			"UTC+6:00 Dhaka",
			"UTC+6:00 Colombo",

			"UTC+7:00 Bangkok",
			"UTC+7:00 Hanoi",
			"UTC+7:00 Jakarta",

			"UTC+8:00 Beijing",
			"UTC+8:00 Chongqing",
			"UTC+8:00 Guangzhou",
			"UTC+8:00 Shanghai",
			"UTC+8:00 Hong Kong",
			"UTC+8:00 Urumchi",
			"UTC+8:00 Taipei",
			"UTC+8:00 Singapore",
			"UTC+8:00 Perth",

			"UTC+9:00 Pyongyang",
			"UTC+9:00 Seoul",
			"UTC+9:00 Tokyo",
			"UTC+9:00 Osaka",
			"UTC+9:00 Sapporo",
			"UTC+9:00 Yakutsk",

			"UTC+10:00 Brisbane",
			"UTC+10:00 Guam",
			"UTC+10:00 Port Moresby",
			"UTC+10:00 Hobart",
			"UTC+10:00 Canberra",
			"UTC+10:00 Melbourne",
			"UTC+10:00 Sydney",

			"UTC+11:00 Magadan",
			"UTC+11:00 Solomon Islands",
			"UTC+11:00 New Caledonia",

			"UTC+12:00 Auckland",
			"UTC+12:00 Wellington",
			"UTC+12:00 Fiji",
			"UTC+12:00 Kamchatka Peninsula",
			"UTC+12:00 Marshall Islands",

			"UTC-3:30 Newfoundland",
			"UTC+3:30 Teheran or Tehran",
			"UTC+4:30 Kabul",
			"UTC+5:30 Bombay",
			"UTC+5:30 Calcutta",
			"UTC+5:30 Madras",
			"UTC+5:30 New Delhi",
			"UTC+9:30 Adelaide, Darwin"
		);

		var timeZoneIndexValue = new Array(
			720,
			720,
			660,
			660,
			600,
			540,
			480,
			480,
			420,
			420,
			360,
			360,
			360,
			360,
			300,
			300,
			300,
			300,
			300,
			240,
			240,
			240,
			180,
			180,
			180,
			120,
			60,
			60,
			0,
			0,
			0,
			0,
			0,
			0,

			-60, -60, -60, -60, -60, -60, -60, -60, -60, -60, -60, -60, -60, -60, -60, -60, -60, -60, -60,

			-120, -120, -120, -120, -120, -120, -120, -120, -120, -120,

			-180, -180, -180, -180, -180, -180, -180,

			-240, -240, -240, -240,

			-300, -300, -300, -300,

			-360, -360, -360,

			-420, -420, -420,

			-480, -480, -480, -480, -480, -480, -480, -480, -480,

			-540, -540, -540, -540, -540, -540,

			-600, -600, -600, -600, -600, -600, -600,

			-660, -660, -660,

			-720, -720, -720, -720, -720,

			210, -210, -270, -330, -330, -330, -330, -570
		);

		var timeZone = new Array(
			timeZoneCn, timeZoneEn
		);

		var languageType = new Array(
			"中文",
			"English"
		);

		//		var lang_sel =  parseInt(options.lang_sel);

		var strCn = new Array(
			"语言版本", "设置时区", "确认", "取消", "查看更多"
		);
		var strEn = new Array(
			"Language Version", "Set Timezone", "Confirm", "Cancle", "Load more"
		);
		var strCnEn = new Array(
			strCn, strEn
		);

		//		var lastDay = new Array(
		//			"2016-09-05 09:30 主机报警",
		//			"2016-09-05 09:30 主机报警",
		//			"2016-09-05 09:30 主机报警",
		//			"2016-09-05 09:30 主机报警",
		//			"2016-09-05 09:30 主机报警",
		//			"2016-09-05 09:30 主机报警"
		//		);
		//
		//		var yestoday = new Array(
		//			"2016-09-06 09:30 主机报警",
		//			"2016-09-06 09:30 主机报警",
		//			"2016-09-06 09:30 主机报警",
		//			"2016-09-06 09:30 主机报警",
		//			"2016-09-06 09:30 主机报警",
		//			"2016-09-06 09:30 主机报警"
		//		);
		//
		//		var today = new Array(
		//			"2016-09-07 09:30 主机报警",
		//			"2016-09-07 09:30 主机报警",
		//			"2016-09-07 09:30 主机报警",
		//			"2016-09-07 09:30 主机报警",
		//			"2016-09-07 09:30 主机报警",
		//			"2016-09-07 09:30 主机报警"
		//		);

		//插件默认选项

		var that = $(this);
		var docType = $(this).is('input');
		var datetime = false;
		var nowdate = new Date();
		var indexY = 1,//li的索引从1开始
			indexM = 1,
			indexD = 1;
		var indexH = 1,
			indexI = 1,
			indexS = 0;
		//		var initY = parseInt((nowdate.getYear() + "").substr(1, 2));

		var itemNum = 1;
		var itemShowType = 1;
		if(options.type == "language") {
			itemNum = languageType.length;
			itemShowType = 1;
		}

		if(options.type == "timezone") {
			itemNum = timeZoneCn.length;
			itemShowType = 2;
		}

		if(options.type == "event_record") {
			//			itemNum = timeZoneCn.length;
			itemShowType = 3;
		}

		var initY;

		//		var initY = 1 - 1; //初始化  显示的索引 真正的索引5
		var initM = parseInt(nowdate.getMonth() + "") + 1;
		var initD = parseInt(nowdate.getDate() + "");
		var initH = parseInt(nowdate.getHours());
		var initI = parseInt(nowdate.getMinutes());
		var initS = parseInt(nowdate.getYear());
		var yearScroll = null,
			monthScroll = null,
			dayScroll = null;
		var HourScroll = null,
			MinuteScroll = null,
			SecondScroll = null;

		$.fn.date.defaultOptions = {
				beginyear: 0, //日期--年--份开始
				endyear: itemNum, //日期--年--份结束
				beginmonth: 1, //日期--月--份结束
				endmonth: 12, //日期--月--份结束
				beginday: 1, //日期--日--份结束
				endday: 31, //日期--日--份结束
				beginhour: 1,
				endhour: 12,
				beginminute: 00,
				endminute: 59,
				curdate: false, //打开日期是否定位到当前日期
				theme: "date", //控件样式（1：日期，2：日期+时间）
				mode: null, //操作模式（滑动模式）
				event: "click", //打开日期插件默认方式为点击后后弹出日期 
				show: true
			}
			//用户选项覆盖插件默认选项   
		var opts = $.extend(true, {}, $.fn.date.defaultOptions, options);
		if(opts.theme === "datetime") {
			datetime = true;
		}
		if(!opts.show) {
			that.unbind('click');
		}
		/*www.sucaijiayuan.com*/
		else {
			//绑定事件（默认事件为获取焦点）

			that.bind(opts.event, function() {

				if(itemShowType != 3) {
					createUL(); //动态生成控件显示的日期
					init_iScrll(); //初始化iscrll
					extendOptions(); //显示控件
					that.blur(); //失去焦点回调
					if(datetime) { //不管 用不上
						showdatetime();
						refreshTime();
					}

					refreshDate();
					bindButton();
				} else {
					createUL1(); //动态生成控件显示的日期
					init_iScrll1(); //初始化iscrll
					extendOptions(); //显示控件
					that.blur(); //失去焦点回调
					refreshDate1();
					bindButton1();
				}

			})
		};

		function refreshDate() {
			if(itemShowType == 1) {
				initY = lang_sel;
			}

			console.log(lang_sel);

			if(itemShowType == 2) {
				initY = 0; //抽取再定
			}

			yearScroll.refresh();
			monthScroll.refresh();
			dayScroll.refresh();

//			resetInitDete();
			yearScroll.scrollTo(0, initY * 40, 100, true);
			//			console.log("refreshDate:initY:" + initY);

			monthScroll.scrollTo(0, initM * 40 - 40, 100, true);
			dayScroll.scrollTo(0, initD * 40 - 40, 100, true);
		}

		function refreshTime() {
			HourScroll.refresh();
			MinuteScroll.refresh();
			SecondScroll.refresh();
			if(initH > 12) { //判断当前时间是上午还是下午
				SecondScroll.scrollTo(0, initD * 40 - 40, 100, true); //显示“下午”
				initH = initH - 12 - 1;
			}
			HourScroll.scrollTo(0, initH * 40, 100, true);
			MinuteScroll.scrollTo(0, initI * 40, 100, true);
			initH = parseInt(nowdate.getHours());
		}

		function resetIndex() {
			indexY = 1;
			indexM = 1;
			indexD = 1;
		}

		function resetInitDete() {
//			if(opts.curdate) {
//				return false;
//			} else if(that.val() === "") {
//				return false;
//			}
			//			initY = parseInt(that.val().substr(2, 2));
			//			initY = parseInt(that.val()) - 1; //注意-1

			var input_str = that.val();
			var i = 0;

			if(itemShowType == 1) {
				for(i = 0; i < languageType.length; i++) {
					if(input_str == languageType[i]) {
						initY = i; //注意-1
					}
				}
			}

			if(itemShowType == 2) {
				for(i = 0; i < timeZoneCn.length; i++) {
					if(input_str == timeZone[lang_sel][i]) {
						initY = i; //注意-1
					}
				}
			}

			if(itemShowType == 3) {
				if(cur_titTab_select_index == 0) {
					initY = lastDay.length - 1;
				}
				if(cur_titTab_select_index == 1) {
					initY = yestoday.length - 1;
				}
				if(cur_titTab_select_index == 2) {
					initY = today.length - 1;
				}
			}

			//			initM = parseInt(that.val().substr(5, 2));
			//			initD = parseInt(that.val().substr(8, 2));

			//			console.log("resetInitDete:initY:" + initY);
		}

		function bindButton() {
			resetIndex();
			$("#dateconfirm").unbind('click').click(function() {
				var datestr = $("#yearwrapper ul li:eq(" + indexY + ")").html();
				console.log("indexY:" + indexY); //1 ~length

				//指令调用
				if(itemShowType == 1) {
					SetLang(indexY - 1);
				}
				if(itemShowType == 2) {
					SyncDateTime(timeZoneIndexValue[indexY - 1]);
				}

				//				命令层
				//					+ "-" +
				//					$("#monthwrapper ul li:eq(" + indexM + ")").html().substr(0, $("#monthwrapper ul li:eq(" + indexM + ")").html().length - 1) + "-" +
				//					$("#daywrapper ul li:eq(" + Math.round(indexD) + ")").html().substr(0, $("#daywrapper ul li:eq(" + Math.round(indexD) + ")").html().length - 1);
				//				if(datetime) {
				//					if(Math.round(indexS) === 1) { //下午
				//						$("#Hourwrapper ul li:eq(" + indexH + ")").html(parseInt($("#Hourwrapper ul li:eq(" + indexH + ")").html().substr(0, $("#Hourwrapper ul li:eq(" + indexH + ")").html().length - 1)) + 12)
				//					} else {
				//						$("#Hourwrapper ul li:eq(" + indexH + ")").html(parseInt($("#Hourwrapper ul li:eq(" + indexH + ")").html().substr(0, $("#Hourwrapper ul li:eq(" + indexH + ")").html().length - 1)))
				//					}
				//					datestr += " " + $("#Hourwrapper ul li:eq(" + indexH + ")").html().substr(0, $("#Minutewrapper ul li:eq(" + indexH + ")").html().length - 1) + ":" +
				//						$("#Minutewrapper ul li:eq(" + indexI + ")").html().substr(0, $("#Minutewrapper ul li:eq(" + indexI + ")").html().length - 1);
				//					indexS = 0;
				//				}

				if(Ycallback === undefined) {
					if(docType) {
						//						that.val(datestr);
					} else {
						//						that.html(datestr);
					}
				} else {
					Ycallback(datestr);
				}
				$("#datePage").hide();
				$("#dateshadow").hide();
			});
			$("#datecancle").click(function() {
				$("#datePage").hide();
				$("#dateshadow").hide();
				if(Ncallback != null) {
					Ncallback(false);
				}
			});
		}

		function extendOptions() {
			$("#datePage").show();
			$("#dateshadow").show();
		}
		//日期滑动
		function init_iScrll() {
			//			var strY = $("#yearwrapper ul li:eq(" + indexY + ")").html().substr(0, $("#yearwrapper ul li:eq(" + indexY + ")").html().length -1);

			var strY = $("#yearwrapper ul li:eq(" + indexY + ")").html(); //获取用户选中的值

			var strM = $("#monthwrapper ul li:eq(" + indexM + ")").html().substr(0, $("#monthwrapper ul li:eq(" + indexM + ")").html().length - 1);
			yearScroll = new iScroll("yearwrapper", {
				snap: "li",
				vScrollbar: false,
				onScrollEnd: function() {
					indexY = (this.y / 40) * (-1) + 1; //每个行数的高度固定40px
					//					console.log("onScrollEnd:indexY:" + indexY);
					//					opts.endday = checkdays(strY, strM);
					$("#daywrapper ul").html(createDAY_UL());
					dayScroll.refresh();
				}
			});

			monthScroll = new iScroll("monthwrapper", {
				snap: "li",
				vScrollbar: false,
				onScrollEnd: function() {
					indexM = (this.y / 40) * (-1) + 1;
					opts.endday = checkdays(strY, strM);
					$("#daywrapper ul").html(createDAY_UL());
					dayScroll.refresh();
				}
			});
			dayScroll = new iScroll("daywrapper", {
				snap: "li",
				vScrollbar: false,
				onScrollEnd: function() {
					indexD = (this.y / 40) * (-1) + 1;
				}
			});
		}

		function showdatetime() {
			init_iScroll_datetime();
			addTimeStyle();
			$("#datescroll_datetime").show();
			$("#Hourwrapper ul").html(createHOURS_UL());
			$("#Minutewrapper ul").html(createMINUTE_UL());
			$("#Secondwrapper ul").html(createSECOND_UL());
		}

		//日期+时间滑动
		function init_iScroll_datetime() {
			HourScroll = new iScroll("Hourwrapper", {
				snap: "li",
				vScrollbar: false,
				onScrollEnd: function() {
					indexH = Math.round((this.y / 40) * (-1)) + 1;
					HourScroll.refresh();
				}
			})
			MinuteScroll = new iScroll("Minutewrapper", {
				snap: "li",
				vScrollbar: false,
				onScrollEnd: function() {
					indexI = Math.round((this.y / 40) * (-1)) + 1;
					HourScroll.refresh();
				}
			})
			SecondScroll = new iScroll("Secondwrapper", {
				snap: "li",
				vScrollbar: false,
				onScrollEnd: function() {
					indexS = Math.round((this.y / 40) * (-1));
					HourScroll.refresh();
				}
			})
		}

		function checkdays(year, month) {
			var new_year = year; //取当前的年份        
			var new_month = month++; //取下一个月的第一天，方便计算（最后一天不固定）        
			if(month > 12) //如果当前大于12月，则年份转到下一年        
			{
				new_month -= 12; //月份减        
				new_year++; //年份增        
			}
			var new_date = new Date(new_year, new_month, 1); //取当年当月中的第一天        
			return(new Date(new_date.getTime() - 1000 * 60 * 60 * 24)).getDate(); //获取当月最后一天日期    
		}

		function createUL() {
			CreateDateUI();
			$("#yearwrapper ul").html(createYEAR_UL());
			$("#monthwrapper ul").html(createMONTH_UL());
			$("#daywrapper ul").html(createDAY_UL());
		}

		function CreateDateUI() {
			var titleStr;
			var confirmStr;
			var cancleStr;
			if(itemShowType == 1) {
				titleStr = strCnEn[lang_sel][0];
			}

			if(itemShowType == 2) {
				titleStr = strCnEn[lang_sel][1];
			}

			confirmStr = strCnEn[lang_sel][2];
			cancleStr = strCnEn[lang_sel][3];

			var str = '' +
				'<div id="dateshadow"></div>' +
				'<div id="datePage" class="page">' +
				'<section>' +
				"<div id=\"datetitle\"><h1>" + titleStr + "</h1></div>" +
				'<div id="datemark"><a id="markyear"></a><a id="markmonth"></a><a id="markday"></a></div>' +
				'<div id="timemark" style="display:none"><a id="markhour"></a><a id="markminut"></a><a id="marksecond"></a></div>' +
				'<div id="datescroll">' +
				'<div id="yearwrapper">' +
				'<ul></ul>' +
				'</div>' +
				'<div id="monthwrapper" style ="display:none">' +
				'<ul></ul>' +
				'</div>' +
				'<div id="daywrapper" style ="display:none">' +
				'<ul></ul>' +
				'</div>' +
				'</div>' +
				'<div id="datescroll_datetime">' +
				'<div id="Hourwrapper">' +
				'<ul></ul>' +
				'</div>' +
				'<div id="Minutewrapper">' +
				'<ul></ul>' +
				'</div>' +
				'<div id="Secondwrapper">' +
				'<ul></ul>' +
				'</div>' +
				'</div>' +
				'</section>' +
				'<footer id="dateFooter">' +
				'<div id="setcancle">' +
				'<ul>' +
				"<li id=\"dateconfirm\">" + confirmStr + "</li>" +
				"<li id=\"datecancle\">" + cancleStr + "</li>" +
				'</ul>' +
				'</div>' +
				'</footer>' +
				'</div>';
			$("#datePlugin").html(str);
		}

		function CreateDateUI1() {
			var titleStr;
			var confirmStr;
			var cancleStr;
			if(itemShowType == 1) {
				titleStr = strCnEn[lang_sel][0];
			}

			if(itemShowType == 2) {
				titleStr = strCnEn[lang_sel][1];
			}

			confirmStr = strCnEn[lang_sel][2];
			cancleStr = strCnEn[lang_sel][4];

			var str = '' +
				'<div id="dateshadow"></div>' +
				'<div id="datePage" class="page">' +
				'<section>' +
				"<div id=\"datetitle\"><h1>" + titleStr + "</h1></div>" +
				'<div id="datemark"><a id="markyear"></a><a id="markmonth"></a><a id="markday"></a></div>' +
				'<div id="timemark" style="display:none"><a id="markhour"></a><a id="markminut"></a><a id="marksecond"></a></div>' +
				'<div id="datescroll">' +
				'<div id="yearwrapper">' +
				'<ul></ul>' +
				'</div>' +
				'<div id="monthwrapper" style ="display:none">' +
				'<ul></ul>' +
				'</div>' +
				'<div id="daywrapper" style ="display:none">' +
				'<ul></ul>' +
				'</div>' +
				'</div>' +
				'<div id="datescroll_datetime">' +
				'<div id="Hourwrapper">' +
				'<ul></ul>' +
				'</div>' +
				'<div id="Minutewrapper">' +
				'<ul></ul>' +
				'</div>' +
				'<div id="Secondwrapper">' +
				'<ul></ul>' +
				'</div>' +
				'</div>' +
				'</section>' +
				'<footer id="dateFooter">' +
				'<div id="setcancle">' +
				'<ul>' +
				"<li id=\"dateconfirm\">" + confirmStr + "</li>" +
				"<li id=\"datecancle\">" + cancleStr + "</li>" +
				'</ul>' +
				'</div>' +
				'</footer>' +
				'</div>';
			$("#datePlugin").html(str);
		}

		function addTimeStyle() {
			$("#datePage").css("height", "380px");
			$("#datePage").css("top", "60px");
			$("#yearwrapper").css("position", "absolute");
			$("#yearwrapper").css("bottom", "200px");
			$("#monthwrapper").css("position", "absolute");
			$("#monthwrapper").css("bottom", "200px");
			$("#daywrapper").css("position", "absolute");
			$("#daywrapper").css("bottom", "200px");
		}


		//创建 --年-- 列表
		function createYEAR_UL() {
			var str = "<li>&nbsp;</li>";

			if(itemShowType == 1) {
				for(var i = opts.beginyear; i < opts.endyear; i++) {
					str += '<li>' + languageType[i] + '</li>'
				}
			}

			if(itemShowType == 2) {
				for(var i = opts.beginyear; i < opts.endyear; i++) {
					str += '<li>' + timeZone[lang_sel][i] + '</li>'
				}
			}

			return str + "<li>&nbsp;</li>";;
		}
		//创建 --月-- 列表
		function createMONTH_UL() {
			var str = "<li>&nbsp;</li>";
			for(var i = opts.beginmonth; i <= opts.endmonth; i++) {
				if(i < 10) {
					i = "0" + i
				}
				str += '<li>' + i + '月</li>'
			}
			return str + "<li>&nbsp;</li>";;
		}
		//创建 --日-- 列表
		function createDAY_UL() {
			$("#daywrapper ul").html("");
			var str = "<li>&nbsp;</li>";
			for(var i = opts.beginday; i <= opts.endday; i++) {
				str += '<li>' + i + '日</li>'
			}
			return str + "<li>&nbsp;</li>";;
		}
		//创建 --时-- 列表
		function createHOURS_UL() {
			var str = "<li>&nbsp;</li>";
			for(var i = opts.beginhour; i <= opts.endhour; i++) {
				str += '<li>' + i + '时</li>'
			}
			return str + "<li>&nbsp;</li>";;
		}
		//创建 --分-- 列表
		function createMINUTE_UL() {
			var str = "<li>&nbsp;</li>";
			for(var i = opts.beginminute; i <= opts.endminute; i++) {
				if(i < 10) {
					i = "0" + i
				}
				str += '<li>' + i + '分</li>'
			}
			return str + "<li>&nbsp;</li>";;
		}
		//创建 --分-- 列表
		function createSECOND_UL() {
			var str = "<li>&nbsp;</li>";
			str += "<li>上午</li><li>下午</li>"
			return str + "<li>&nbsp;</li>";;
		}

		function createUL1() {
			CreateDateUI1();
			$("#datetitle").html(createTitleTab());
			$("#yearwrapper ul").html(createToday());
			$("#monthwrapper ul").html(createMONTH_UL());
			$("#daywrapper ul").html(createDAY_UL());
		}

		function init_iScrll1() {
			//			var strY = $("#yearwrapper ul li:eq(" + indexY + ")").html().substr(0, $("#yearwrapper ul li:eq(" + indexY + ")").html().length -1);

			var strY = $("#yearwrapper ul li:eq(" + indexY + ")").html(); //获取用户选中的值

			var strM = $("#monthwrapper ul li:eq(" + indexM + ")").html().substr(0, $("#monthwrapper ul li:eq(" + indexM + ")").html().length - 1);
			yearScroll = new iScroll("yearwrapper", {
				snap: "li",
				vScrollbar: false,
				onScrollEnd: function() {
					indexY = (this.y / 40) * (-1) + 1; //每个行数的高度固定40px
					//					//					console.log("onScrollEnd:indexY:" + indexY);
					//					//					opts.endday = checkdays(strY, strM);
					//					$("#daywrapper ul").html(createDAY_UL());
					//					dayScroll.refresh();
				}
			});

			monthScroll = new iScroll("monthwrapper", {
				snap: "li",
				vScrollbar: false,
				onScrollEnd: function() {
					indexM = (this.y / 40) * (-1) + 1;
					opts.endday = checkdays(strY, strM);
					$("#daywrapper ul").html(createDAY_UL());
					dayScroll.refresh();
				}
			});
			dayScroll = new iScroll("daywrapper", {
				snap: "li",
				vScrollbar: false,
				onScrollEnd: function() {
					indexD = (this.y / 40) * (-1) + 1;
				}
			});
		}

		function bindButton1() {
			resetIndex();
			$("#dateconfirm").unbind('click').click(function() {
				//				var datestr = $("#yearwrapper ul li:eq(" + indexY + ")").html();
				//				console.log("indexY:" + indexY); //1 ~length

				//				if(Ycallback === undefined) {
				//					if(docType) {
				//						that.val(datestr);
				//					} else {
				//						that.html(datestr);
				//					}
				//				} else {
				//					Ycallback(datestr);
				//				}
				$("#datePage").hide();
				$("#dateshadow").hide();
			});

			$("#datecancle").click(function() {
				//消失对话框 下面两行
				//				$("#datePage").hide();
				//				$("#dateshadow").hide();

				//				if(Ncallback != null) {
				//					Ncallback(false);
				//				}
				yearScroll.refresh();

				/// 额外增加数据
				if(cur_titTab_select_index == 0) {
					moreDealWithTheAlarmData2();

					$("#yearwrapper ul").html(createLastDay());
				}
				if(cur_titTab_select_index == 1) {
					moreDealWithTheAlarmData1();
					$("#yearwrapper ul").html(createYeartoday());
				}
				if(cur_titTab_select_index == 2) {

					moreDealWithTheAlarmData0();
					$("#yearwrapper ul").html(createToday());
				}

				loadMoreDataRefresh();
				//				resetIndex();
			});

			$("#date_1").click(function() {
				cur_titTab_select_index = 0;
				dateSelect(1);
			});
			$("#date_2").click(function() {
				cur_titTab_select_index = 1;
				dateSelect(2);
			});
			$("#date_3").click(function() {
				cur_titTab_select_index = 2;
				dateSelect(3);
			});
		}

		function getClientWidth() {

			var width = document.documentElement.clientWidth;
			if(width > 640) {
				width = 640;
			}

			if(width < 320) {
				width = 320;
			}

			return width;
		}

		//前天1 昨天2  今天3s
		//日期切换
		function dateSelect(parm) {

			if(parm == 1) {
				$("#yearwrapper ul").html(createLastDay());
			}
			if(parm == 2) {
				$("#yearwrapper ul").html(createYeartoday());
			}
			if(parm == 3) {
				$("#yearwrapper ul").html(createToday());
			}

			refreshDate1();
			resetIndex();
		}

		var cur_titTab_select_index = 2; //0 更早  1昨天 2今天

		function createTitleTab() {

			var width = document.documentElement.clientWidth;
			if(width > 640) {
				width = 640;
			}

			if(width < 320) {
				width = 320;
			}

			var border_width = 1;
			var total_border_width = 3 * 2 * border_width;
			var li_width_pensent = (width - total_border_width) / 3.0;

			var dateArrCn = new Array(
				"更早前",
				"昨天",
				"今天"
			);

			var dateArrEn = new Array(
				"earlier",
				"yesterday",
				"today"
			);

			var dateArr = new Array(
				dateArrCn,
				dateArrEn
			);

			var str = "";
			str += "<ul class=\"dateList\" id=\"date_list\">";

			var i = 0;
			for(i = 0; i < 3; i++) {
				str += "<li style=\"width:" + li_width_pensent + "px;  border:#d4d9de" + border_width + "px solid;\">";
				//				str += "<input onclick=\"dateSelect(" + (i + 1) + ")\" id=\"date_" + (i + 1) + "\" class=\"radio\" name=\"moshi\" type=\"radio\" />";

				if(i == 2) {

					str += "<input id=\"date_" + (i + 1) + "\" class=\"radio\" name=\"moshi\" type=\"radio\" checked />";
				} else {
					str += "<input id=\"date_" + (i + 1) + "\" class=\"radio\" name=\"moshi\" type=\"radio\" />";
				}
				str += "<label for=\"date_" + (i + 1) + "\" class=\"trigger\"><p id=\"dateSt_" + (i + 1) + "\">" + dateArr[lang_sel][i] + "</p></label>";
				str += "</li>";
			}
			str += "</ul>"

			return str;
		}

		function createToday() {
			var str = "<li>&nbsp;</li>";

			for(var i = 0; i < today.length; i++) {
				str += '<li>' + today[i] + '</li>'
			}

			return str + "<li>&nbsp;</li>";;
		}

		function createYeartoday() {
			var str = "<li>&nbsp;</li>";

			for(var i = 0; i < yestoday.length; i++) {
				str += '<li>' + yestoday[i] + '</li>'
			}

			return str + "<li>&nbsp;</li>";;
		}

		function createLastDay() {
			var str = "<li>&nbsp;</li>";

			for(var i = 0; i < lastDay.length; i++) {
				str += '<li>' + lastDay[i] + '</li>'
			}
			return str + "<li>&nbsp;</li>";;
		}

		function refreshDate1() {

			initY = 0;
			yearScroll.refresh();
			monthScroll.refresh();
			dayScroll.refresh();

//			resetInitDete();
			//			yearScroll.scrollTo(0, 0, 0, true);
			yearScroll.scrollTo(0, initY * 40, 100, false);
			//			console.log("refreshDate:initY:" + initY);

			monthScroll.scrollTo(0, initM * 40 - 40, 100, true);
			dayScroll.scrollTo(0, initD * 40 - 40, 100, true);
		}

		function loadMoreDataRefresh() {

			initY = 0;
			yearScroll.refresh();
			monthScroll.refresh();
			dayScroll.refresh();

//			resetInitDete();
			//			yearScroll.scrollTo(0, 0, 0, true);
			yearScroll.scrollTo(0, initY * 40, 100, true);
			//			console.log("refreshDate:initY:" + initY);

			monthScroll.scrollTo(0, initM * 40 - 40, 100, true);
			dayScroll.scrollTo(0, initD * 40 - 40, 100, true);
		}
	}
})(jQuery);